package com.example.takatomuzyka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TakatomuzykaApplicationTests {

    @Test
    void contextLoads() {
    }

}
